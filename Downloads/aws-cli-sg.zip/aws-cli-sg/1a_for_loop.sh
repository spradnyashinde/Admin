#!/bin/bash
for i in $(cat inbound_rules.csv);
do
    # i=>10.0.0.1/32,80
    INBOUND_IP=$(echo $i | awk -F, '{ print $1}')
    INBOUND_PORT=$(echo $i | awk -F, '{ print $2}')
    echo "Inbound ip is $INBOUND_IP"
    echo "Inbound port is $INBOUND_PORT"
done