# Function Definition
def greet_user():
    """Display a simple greeting."""
    '''this is comment'''
    print("Hello!")
print("World!")

# Function Call
greet_user()
greet_user()
greet_user()