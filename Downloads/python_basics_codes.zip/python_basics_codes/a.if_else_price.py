age = 21
if age < 4:
	print("Assigning value of ticket_price variable as 0")
	ticket_price = 0
elif age < 18:
	print("Assigning value of ticket_price variable as 10")
	ticket_price = 10
else:
	print("Assigning value of ticket_price variable as 15")
	ticket_price = 15

print("ticket_price final value is",ticket_price)