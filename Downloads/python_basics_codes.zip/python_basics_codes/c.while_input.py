msg = ''
while msg != 'quit':
	msg = input("Type your message? ")
	print(msg)