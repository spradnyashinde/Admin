# Function Defination
def add_numbers(x, y):
    print("Inside add_numbers function")
    addition_results = x + y
    return addition_results

sum1 = add_numbers(3, 5)
sum2 = add_numbers(10, 15)
print("Value of sum1",sum1)
print("Value of sum2",sum2)